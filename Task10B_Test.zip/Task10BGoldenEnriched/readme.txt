The following question has been removed from batch 3, due to technical reasons: 604e7ce494d57fd879000006 
